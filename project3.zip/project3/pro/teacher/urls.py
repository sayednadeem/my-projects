from django.urls import path
from .views import *

urlpatterns=[
    path('addmark/',AddMarkView.as_view(),name="add"),
    path('addstu/',AddStudentMView.as_view(),name="addstudent"),
    path('viewstu/',StudentView.as_view(),name="viewstu"),
    path('delstudent/<int:ssid>',DeleteStudeent.as_view(),name="delstu"),
    path('editstudent/<int:sid>',EditMStudeent.as_view(),name="editstu")
]