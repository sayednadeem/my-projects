from django.http import HttpResponse
from django.shortcuts import render,redirect
from django.views.generic import View
from .forms import AddMarkForm
from .forms import StudentForm,StudentMForm
from django.contrib import messages
from .models import StudentModel


# Create your views here.

class AddMarkView(View):
    def get(self,request,*args,**kwargs):
        f=AddMarkForm()
        return render(request,"addmark.html",{"form":f})
    def post(self,request,*args,**kwargs):
        form_data=AddMarkForm(data=request.POST)
        if form_data.is_valid():
            m1=form_data.cleaned_data.get("mark1")
            m2=form_data.cleaned_data.get("mark2")
            m3=form_data.cleaned_data.get("mark3")
            m4=form_data.cleaned_data.get("mark4")
            m5=form_data.cleaned_data.get("mark5")
            mark=int(m1)+int(m2)+int(m3)+int(m4)+int(m5)
            return render(request,"addmark.html",{"res":mark})
        else:
            return render(request,"addmark.html",{"form":form_data})
           
    
# class AddStudentView(View):
#     def get(self,request,*args,**kwargs):
#         f=StudentForm()
#         return render(request,"addstu.html",{"form":f})
#     def post(self,request,*args,**kwargs):
#         form_data=StudentForm(data=request.POST)
#         if form_data.is_valid():
#             fname=(form_data.cleaned_data.get("first_name"))
#             lname=(form_data.cleaned_data.get("last_name"))
#             age=(form_data.cleaned_data.get("age"))
#             address=(form_data.cleaned_data.get("address"))
#             email=(form_data.cleaned_data.get("email"))
#             phone=(form_data.cleaned_data.get("phone"))
#             StudentModel.objects.create(first=fname,last=lname,age=age,phone=phone,email=email,address=address)
#             messages.success(request,"Student added successfully!!")
#             return redirect("h")
#         else:
#             messages.error(request,"Submit adding failed!!!!")
#             return render(request,"addstu.html",{"form":form_data})

class AddStudentMView(View):
    def get(self,request,*args,**kwargs):
        f=StudentMForm()
        return render(request,"addstu.html",{"form":f})
    def post(self,request,*args,**kwargs):
        form_data=StudentMForm(data=request.POST,files=request.FILES)
        if form_data.is_valid():
            form_data.save()
            messages.success(request,"Student added successfully!!")
            return redirect("h")
        else:
            messages.error(request,"Submit adding failed!!!!")
            return render(request,"addstu.html",{"form":form_data})

class StudentView(View):
    def get(self,request,*args,**kwargs):
        res=StudentModel.objects.all()
        return render(request,"viewstu.html",{"data":res})
    
class DeleteStudeent(View):
    def get(self,request,*args,**kwargs):
        sid=kwargs.get("ssid")
        stu=StudentModel.objects.get(id=sid)
        stu.delete()
        return redirect("viewstudent")

# class EditStudeent(View):
#     def get(self,request,*args,**kwargs):
#         id=kwargs.get("sid")
#         stu=StudentModel.objects.get(id=id)
#         f=StudentForm(initial={"first_name":stu.first,"last_name":stu.last,"age":stu.age,"address":stu.address,"email":stu.email,"phone":stu.phone})
#         return render(request,"editstudent.html",{"form":f})
#     def post(self,request,*args,**kwargs):
#         form_data=StudentForm(data=request.POST)
#         if form_data.is_valid():
#             fname=(form_data.cleaned_data.get("first_name"))
#             lname=(form_data.cleaned_data.get("last_name"))
#             age=(form_data.cleaned_data.get("age"))
#             address=(form_data.cleaned_data.get("address"))
#             email=(form_data.cleaned_data.get("email"))
#             phone=(form_data.cleaned_data.get("phone"))
#             id=kwargs.get("sid")
#             stu=StudentModel.objects.get(id=id)
#             stu.first=fname
#             stu.last=lname
#             stu.age=age
#             stu.address=address
#             stu.email=email
#             stu.phone=phone
#             stu.save()
#             messages.success(request,"Student-Details Update Successfully!!")
#             return redirect("viewstu")
#         else:
#             messages.error(request,"Updation Failed")
#             return render(request,"editstudent.html",{"form":form_data})

class EditMStudeent(View):
    def get(self,request,*args,**kwargs):
        id=kwargs.get("sid")
        stu=StudentModel.objects.get(id=id)
        f=StudentMForm(instance=stu)
        return render(request,"editstudent.html",{"form":f})
    def post(self,request,*args,**kwargs):
        id=kwargs.get("sid")
        stu=StudentModel.objects.get(id=id)
        form_data=StudentMForm(data=request.POST,instance=stu,files=request.FILES)
        if form_data.is_valid():
            form_data.save()
            messages.success(request,"Student-Details Update Successfully!!")
            return redirect("viewstu")
        else:
            messages.error(request,"Updation Failed")
            return render(request,"editstudent.html",{"form":form_data})