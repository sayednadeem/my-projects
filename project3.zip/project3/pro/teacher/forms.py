from django import forms
from .models import StudentModel


class AddMarkForm(forms.Form):
    mark1=forms.IntegerField(label="Enter Mark of Subject1")
    mark2=forms.IntegerField(label="Enter Mark of Subject2")
    mark3=forms.IntegerField(label="Enter Mark of Subject3")
    mark4=forms.IntegerField(label="Enter Mark of Subject4")
    mark5=forms.IntegerField(label="Enter Mark of Subject5")
    def clean(self):
        cleaned_data=super().clean()
        m1=cleaned_data.get("mark1")
        m2=cleaned_data.get("mark2")
        m3=cleaned_data.get("mark3")
        m4=cleaned_data.get("mark4")
        m5=cleaned_data.get("mark5")

        if m1<0:
            msg="Mark less than zero.Invalid Input"
            self.add_error("mark1",msg)
        if m2<0:
            msg="Mark less than zero.Invalid Input"
            self.add_error("mark2",msg)
        if m3<0:
            msg="Mark less than zero.Invalid Input"
            self.add_error("mark3",msg)
        if m4<0:
            msg="Mark less than zero.Invalid Input"
            self.add_error("mark4",msg)
        if m5<0:
            msg="Mark less than zero.Invalid Input"
            self.add_error("mark5",msg)

class StudentForm(forms.Form):
    first=forms.CharField(max_length=100,widget=forms.TextInput(attrs={"class":"form-control","placeholder":"Enter your first name"}))
    last=forms.CharField(max_length=100,widget=forms.TextInput(attrs={"class":"form-control","placeholder":"Enter your last name"}))
    age=forms.IntegerField(widget=forms.TextInput(attrs={"class":"form-control","placeholder":"Enter your age"}))
    address=forms.CharField(max_length=500,widget=forms.Textarea(attrs={"class":"form-control","placeholder":"Enter your address"}))
    email=forms.EmailField(widget=forms.TextInput(attrs={"class":"form-control","placeholder":"Enter your email"}))
    phone=forms.IntegerField(widget=forms.TextInput(attrs={"class":"form-control","placeholder":"Enter your phone number"}))
    # def clean(self):
    #     cleaned_data=super().clean()
    #     fname=cleaned_data.get("first_name")
    #     lname=cleaned_data.get("last_name")
    #     age=cleaned_data.get("age")
    #     address=cleaned_data.get("address")
    #     email=cleaned_data.get("email")
    #     phone=str(cleaned_data.get("phone"))

    #     if fname==lname:
    #         self.add_error("first_name","firstname and lastname are same")
    #     if age<=0:
    #         self.add_error("age","age is lesser than 1")
    #     if len(phone)!=10:
    #         self.add_error("phone","Number more than 10")

class StudentMForm(forms.ModelForm):
    class Meta:
        model=StudentModel
        fields="__all__"
        widgets={
            "first":forms.TextInput(attrs={"class":"form-control","placeholder":"First Name"}),
            "last":forms.TextInput(attrs={"class":"form-control","placeholder":"Last Name"}),
            "age":forms.NumberInput(attrs={"class":"form-control","placeholder":"Age"}),
            "address":forms.Textarea(attrs={"class":"form-control","placeholder":"Address"}),
            "phone":forms.NumberInput(attrs={"class":"form-control","placeholder":"Phone Number"}),
            "email":forms.EmailInput(attrs={"class":"form-control","placeholder":"Email ID"}),
        }
    def clean(self):
        cleaned_data=super().clean()
        fname=cleaned_data.get("first")
        lname=cleaned_data.get("last")
        age=cleaned_data.get("age")
        address=cleaned_data.get("address")
        email=cleaned_data.get("email")
        phone=str(cleaned_data.get("phone"))

        if fname==lname:
            self.add_error("first","firstname and lastname are same")
        if age<=0:
            self.add_error("age","age is lesser than 1")
        if len(phone)!=10:
            self.add_error("phone","Number more than 10")







