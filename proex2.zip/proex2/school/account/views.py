from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import View

# Create your views here.
class LogView(View):
    def get(self,request,*args,**kwargs):
       return render(request,"log.html")
    def post(self,request,*args,**kwargs):
        print(request.POST.get("uname"))
        print(request.POST.get("pswd"))
        return HttpResponse("uname:"+request.POST.get("uname")+"<br>password:"+request.POST.get("pass"))

class RegView(View):
    def get(self,request,*args,**kwargs):
        return render(request,"register.html")
    def post(self,request,*args,**kwargs):
        print(request.POST.get("fname"))
        print(request.POST.get("lname"))
        print(request.POST.get("em"))
        print(request.POST.get("uname"))
        return HttpResponse("registered")
class MainHome(View):
    def get(self,request,*args,**kwargs):
        return render(request,"main_home.html")

    




