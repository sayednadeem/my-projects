from django.shortcuts import render
from django.views.generic import View
from .forms import AddForm
from .forms import DivForm
from .forms import SubForm

# Create your views here.


class AddView(View):
    def get(self, req, *args, **kwargs):
        f=AddForm()
        return render(req,"add.html",{"form":f})

    def post(self, req, *args, **kwargs):
        num1 = req.POST.get("num1")
        num2 = req.POST.get("num2")
        res = int(num1)+int(num2)
        return render(req,"add.html", {"data": res})


class SubView(View):
    def get(self, req, *args, **kwargs):
        f=SubForm()
        return render(req, "sub.html",{"form":f})

    def post(self, req, *args, **kwargs):
        num1 = req.POST.get("num1")
        num2 = req.POST.get("num2")
        res = int(num1)-int(num2)
        return render(req, "sub.html", {"data": res})


class CountView(View):
    def get(self, req, *args, **kwargs):
        return render(req, "wrdcnt.html")

    def post(self, req, *args, **kwargs):
        sent = req.POST.get("strng")
        words = sent.split(" ")
        cnt = {}
        for i in words:
            if i in cnt:
                cnt[i] += 1
            else:
                cnt[i] = 1
        return render(req, "wrdcnt.html", {"res": cnt})


class DivView(View):
    def get(self, req, *args, **kwargs):
        f=DivForm()
        return render(req, "division.html",{"form":f})

    def post(self, req, *args, **kwargs):
        num1 = req.POST.get("num1")
        num2 = req.POST.get("num2")
        res = int(num1)/int(num2)
        return render(req, "division.html", {"data": res})
