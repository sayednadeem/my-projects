from django.urls import path
from .views import *
urlpatterns = [
    path('add/', AddView.as_view(), name="add"),
    path('sub/', SubView.as_view(), name="sub"),
    path('count/', CountView.as_view(), name="strng"),
    path('div/', DivView.as_view(), name="div"),

]
